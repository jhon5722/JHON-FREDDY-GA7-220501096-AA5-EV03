from fastapi import FastAPI, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from .database import engine, Base, get_db
from .models import models
from .schemas import schemas

# Crear tablas
models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Zapatillas JyR API",
    description="API para la gestión de ventas de zapatillas online",
    version="1.0.0"
)

# --- Endpoints de Productos ---

@app.get("/products", response_model=List[schemas.Product], tags=["Productos"])
def get_products(db: Session = Depends(get_db)):
    """Obtener el catálogo completo de zapatillas."""
    return db.query(models.Product).all()

@app.post("/products", response_model=schemas.Product, tags=["Productos"])
def create_product(product: schemas.ProductCreate, db: Session = Depends(get_db)):
    """Agregar una nueva zapatilla al catálogo (Admin)."""
    db_product = models.Product(**product.dict())
    db.add(db_product)
    db.commit()
    db.refresh(db_product)
    return db_product

# --- Endpoints de Usuarios (Simplificado para la entrega) ---

@app.post("/users/register", response_model=schemas.User, tags=["Usuarios"])
def register_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    """Registrar un nuevo cliente."""
    db_user = models.User(
        username=user.username, 
        email=user.email, 
        hashed_password=user.password # En producción usar hashing
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

# --- Endpoints de Pedidos ---

@app.post("/orders", response_model=schemas.Order, tags=["Pedidos"])
def create_order(order_data: schemas.OrderCreate, user_id: int, db: Session = Depends(get_db)):
    """Crear un nuevo pedido de zapatillas."""
    total = 0
    # Calcular total y verificar stock (simplificado)
    new_order = models.Order(user_id=user_id, total_price=0)
    db.add(new_order)
    db.commit()
    db.refresh(new_order)
    
    for item in order_data.items:
        product = db.query(models.Product).filter(models.Product.id == item.product_id).first()
        if product:
            order_item = models.OrderItem(
                order_id=new_order.id,
                product_id=product.id,
                quantity=item.quantity,
                price=product.price
            )
            total += product.price * item.quantity
            db.add(order_item)
    
    new_order.total_price = total
    db.commit()
    db.refresh(new_order)
    return new_order
